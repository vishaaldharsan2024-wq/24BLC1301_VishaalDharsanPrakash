# Library Management System

Backend Library Management System developed using FastAPI and MongoDB.

Features:

* Student CRUD
* Book CRUD
* Borrow / Return Books
* Due Date Tracking
* Staff Management
* Department Management
* Swagger API Testing

Tech Stack:

* Python
* FastAPI
* MongoDB
* PyMongo

Run:

mongod

Activate:

venv\Scripts\activate

Install:

pip install -r requirements.txt

Start:

uvicorn main:app --reload

Open:

http://127.0.0.1:8000/docs
