from fastapi import FastAPI
from database import db
from bson import ObjectId
from datetime import datetime, timedelta

app = FastAPI(

title="Library Management System",

description="FastAPI + MongoDB CRUD Project",

version="1.0"

)


@app.get("/")
def home():
    return {
        "message":"Library API Running"
    }


# CREATE STUDENT
@app.post("/students")
def create_student(name:str):

    student = {
        "name":name
    }

    db.students.insert_one(student)

    return {
        "message":"Student added"
    }


# GET STUDENTS
# GET STUDENTS

# GET STUDENTS

@app.get("/students")

def get_students():

    data=[]


    for student in db.students.find():

        student["_id"]=str(
            student["_id"]
        )


        if "borrowedBooks" in student:

            fixed=[]


            for book in student[
                "borrowedBooks"
            ]:


                if isinstance(
                    book,
                    dict
                ):

                    book[
                        "bookId"
                    ]=str(

                        book[
                            "bookId"
                        ]

                    )

                    fixed.append(
                        book
                    )


                else:

                    fixed.append(

                        str(
                            book
                        )

                    )


            student[
                "borrowedBooks"
            ]=fixed


        data.append(
            student
        )


    return data

# UPDATE STUDENT

@app.put("/students/{id}")
def update_student(
    id:str,
    name:str
):

    db.students.update_one(
        {
            "_id":ObjectId(id)
        },
        {
            "$set":{
                "name":name
            }
        }
    )

    return {
        "message":"Updated"
    }


# DELETE STUDENT
@app.delete("/students/{id}")

def delete_student(
id:str
):

    student = db.students.find_one(

        {
            "_id":
            ObjectId(id)
        }

    )


    if student and "borrowedBooks" in student:

        db.books.update_many(

            {

                "_id":{

                    "$in":

                    student[
                        "borrowedBooks"
                    ]

                }

            },

            {

                "$set":{

                    "available":
                    True

                }

            }

        )


    db.students.delete_one(

        {

            "_id":
            ObjectId(id)

        }

    )



    return {

        "message":

        "Student Deleted"

    }

# CREATE BOOK
@app.post("/books")
def create_book(
    title:str,
    author:str
):

    book = {
        "title":title,
        "author":author,
        "available":True
    }

    db.books.insert_one(book)

    return {
        "message":"Book added"
    }


# GET BOOKS

@app.get("/books")
def get_books():

    data=[]

    for book in db.books.find():

        book["_id"]=str(
            book["_id"]
        )

        data.append(
            book
        )

    return data

# UPDATE BOOK
@app.put("/books/{id}")
def update_book(
    id:str,
    title:str
):

    db.books.update_one(
        {
            "_id":ObjectId(id)
        },

        {
            "$set":{
                "title":title
            }
        }
    )

    return {
        "message":"Book updated"
    }


# DELETE BOOK
@app.delete("/books/{id}")
def delete_book(id:str):

    db.books.delete_one(
        {
            "_id":ObjectId(id)
        }
    )

    return {
        "message":"Book deleted"
    }

# BORROW BOOK

@app.put(
"/borrow"
)

def borrow_book(

student_id:str,

book_id:str

):


    student = db.students.find_one(

        {

            "_id":
            ObjectId(
                student_id
            )

        }

    )


    if student and "borrowedBooks" in student:


        today = datetime.now()


        for borrowed in student[

            "borrowedBooks"

        ]:


            if isinstance(
                borrowed,
                dict
            ):


                due = datetime.strptime(

                    borrowed[
                        "dueDate"
                    ],

                    "%Y-%m-%d"

                )


                if due < today:


                    return {

                        "message":

                        "Cannot Borrow: Overdue Book Exists"

                    }



    book = db.books.find_one(

        {

            "_id":
            ObjectId(
                book_id
            )

        }

    )


    if not book[

        "available"

    ]:


        return {

            "message":

            "Book Not Available"

        }



    due_date = (

        datetime.now()

        +

        timedelta(
            days=14
        )

    )



    db.students.update_one(

        {

            "_id":
            ObjectId(
                student_id
            )

        },

        {

            "$push":{

                "borrowedBooks":{

                    "bookId":

                    ObjectId(
                        book_id
                    ),

                    "dueDate":

                    due_date

                    .strftime(
                        "%Y-%m-%d"
                    )

                }

            }

        }

    )



    db.books.update_one(

        {

            "_id":
            ObjectId(
                book_id
            )

        },

        {

            "$set":{

                "available":
                False

            }

        }

    )



    return {

        "message":

        "Book Borrowed",

        "dueDate":

        due_date

        .strftime(
            "%Y-%m-%d"
        )

    }

@app.get("/departments")
def get_departments():

    data=[]

    for dep in db.departments.find():

        dep["_id"]=str(
            dep["_id"]
        )

        data.append(
            dep
        )

    return data

# CREATE DEPARTMENT

@app.post("/departments")

def create_department(
name:str
):

    db.departments.insert_one(
        {
            "name":name
        }
    )

    return {
        "message":"Department Added"
    }


# CREATE STAFF

@app.post("/staff")

def create_staff(

name:str,

department_id:str

):

    db.staff.insert_one(

        {

            "name":name,

            "departmentId":
            ObjectId(
                department_id
            )

        }

    )

    return {

        "message":
        "Staff Added"

    }


# GET STAFF

@app.get("/staff")

def get_staff():

    data=[]

    for s in db.staff.find():

        s["_id"]=str(
            s["_id"]
        )

        if "departmentId" in s:

            s["departmentId"]=str(
                s["departmentId"]
            )

        data.append(
            s
        )

    return data

@app.put("/return")

def return_book(

student_id:str,
book_id:str

):

    db.students.update_one(

        {
            "_id":
            ObjectId(
                student_id
            )
        },

        {

            "$pull":{

                "borrowedBooks":

                ObjectId(
                    book_id
                )

            }

        }

    )


    db.books.update_one(

        {

            "_id":
            ObjectId(
                book_id
            )

        },

        {

            "$set":{

                "available":
                True

            }

        }

    )


    return {

        "message":

        "Book Returned"

    }

# SEARCH BOOKS

@app.get(
"/books/search"
)

def search_books(
title:str
):

    data=[]

    books = db.books.find(

        {

            "title":{

                "$regex":

                title,

                "$options":

                "i"

            }

        }

    )


    for book in books:

        book["_id"]=str(
            book["_id"]
        )

        data.append(
            book
        )


    return data

@app.get(
"/students/status"
)

def student_status():

    data=[]


    today = datetime.now()


    for student in db.students.find():

        status = "CLEAR"


        if "borrowedBooks" in student:


            for book in student[

                "borrowedBooks"

            ]:


                if isinstance(
                    book,
                    dict
                ):


                    due = datetime.strptime(

                        book[
                            "dueDate"
                        ],

                        "%Y-%m-%d"

                    )


                    if due < today:

                        status = "OVERDUE"

                        break


        data.append(

            {

                "student":

                student[
                    "name"
                ],

                "status":

                status

            }

        )


    return data